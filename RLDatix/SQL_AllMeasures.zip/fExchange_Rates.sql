/****** Script for SelectTopNRows command from SSMS  ******/


SELECT 'Date' = CAST(TRY_CONVERT(datetime, [Date], 111) AS DATE)
      ,'Currency' = CAST([Currency] as VARCHAR(20))
      ,'Exchange' = CAST([Exchange] as decimal(10,4))

INTO [RLDatix].[dbo].[fExchange_Rates]
FROM [RLDatix].[dbo].[stgExchange_Rates]