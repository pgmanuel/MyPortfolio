/****** Script for SelectTopNRows command from SSMS  ******/
use [RLDatix]
GO 

/* IMport SAles Fact */ 


SELECT 'OrderNumber' = CAST([Order Number] AS INT) 
      ,'LineItem' = CAST([Line Item] AS INT)
      ,'OrderDate' = CAST([Order Date] AS date)
      ,'DeliveryDate' = CAST([Delivery Date] AS date)
      ,'CustomerKey' = CAST([CustomerKey] AS INT)
      ,'StoreKey' = CAST ([StoreKey] AS INT)
      ,'ProductKey' = CAST([ProductKey] AS INT)
      ,'Quantity' = CAST([Quantity] AS INT) 
      ,'CurrencyCode' = CAST([Currency Code] AS VARCHAR(5))
INTO [RLDatix].[dbo].[fSales]
FROM [RLDatix].[dbo].[stgSales]


