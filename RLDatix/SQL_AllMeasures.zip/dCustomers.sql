
SELECT 
	   'CustomerKey' = CAST([CustomerKey] AS int)
      ,'Gender' = CAST([Gender] AS varchar(50))
      ,'Name' = CAST([Name] AS VARCHAR(50))
      ,'City' = CAST([City] AS VARCHAR(50))
      ,'StateCode' = CAST([State Code] AS VARCHAR(50))
      ,'State' = CAST([State] AS VARCHAR(50))
      ,'Zip Code' = CAST([Zip Code] AS VARCHAR(50))
      ,'Country' = CAST([Country] AS VARCHAR(100))
      ,'Continent' = CAST([Continent] AS VARCHAR(100))
	  ,'Birthday' = CAST(TRY_CONVERT(datetime, [Birthday], 111) AS DATE)
  INTO [RLDatix].[dbo].[dCustomers]
  FROM [RLDatix].[dbo].[stgCustomers]


