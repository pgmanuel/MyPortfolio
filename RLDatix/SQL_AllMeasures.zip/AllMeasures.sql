

Select * FROM [RLDatix].[dbo].[dProducts] 
Select * FROM [RLDatix].[dbo].[fSales]

/* 01 Tot of Products Sold */

Select count(Quantity) AS [ Tot of Products Sold] 
FROM [RLDatix].[dbo].[fSales]

/* 02 Tot Gross Sales */

Select SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales]
FROM [RLDatix].[dbo].[fSales] AS S
LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 

/* 03 Tot of Orders */

SELECT count(distinct S.OrderNumber) 
FROM [RLDatix].[dbo].[fSales] AS S

/* 04 Tot Cost */

Select SUM(S.[Quantity] * P.[UnitCostUSD]) AS [Tot Cost]
FROM [RLDatix].[dbo].[fSales] AS S
LEFT JOIN [RLDatix]..[dProducts] AS P ON  S.ProductKey = P.ProductKey 

/* 05 Tot Cost */

;WITH TotGrossSales_CTE AS (
	Select SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales], S.OrderNumber, S.OrderDate
	FROM [RLDatix].[dbo].[fSales] AS S
	LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
	GROUP BY S.OrderNumber,S.OrderDate
), TotofOrders_CTE AS (
	SELECT count(distinct S.OrderNumber) as [Tot Orders], S.OrderNumber, S.OrderDate
	FROM [RLDatix].[dbo].[fSales] AS S
	GROUP BY OrderNumber,S.OrderDate
)
Select AVG(GS.[Tot Gross Sales] / totO.[Tot Orders]) AS [AVG Sold per Order] ,YEAR(GS.OrderDate) AS [YEAR]
	FROM TotGrossSales_CTE AS GS
LEFT JOIN TotofOrders_CTE as totO ON GS.OrderNumber = totO.OrderNumber
GROUP BY YEAR(GS.OrderDate)


/* 06 NET Profit */

;WITH TotGrossSales_CTE AS (
	SELECT SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales], S.OrderNumber, S.OrderDate
	FROM [RLDatix].[dbo].[fSales] AS S
	LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
	GROUP BY S.OrderNumber,S.OrderDate
), TotofCost_CTE AS (
	SELECT SUM(S.[Quantity] * P.[UnitCostUSD]) AS [Tot Cost], S.OrderNumber, S.OrderDate
	FROM [RLDatix].[dbo].[fSales] AS S
	LEFT JOIN [RLDatix]..[dProducts] AS P ON  S.ProductKey = P.ProductKey 
	GROUP BY S.OrderNumber,S.OrderDate
)
Select SUM(GS.[Tot Gross Sales] - totC.[Tot Cost]) AS [Net Profit] ,YEAR(GS.OrderDate) AS [YEAR]
INTO #06NETProfit_tmp
	FROM TotGrossSales_CTE AS GS
JOIN TotofCost_CTE as totC ON GS.OrderNumber = totC.OrderNumber
GROUP BY YEAR(GS.OrderDate)	


/* 07 Margin Profit (%) */

;WITH TotGrossSales_CTE AS (
	SELECT SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales], YEAR(S.OrderDate) as [Year]
	FROM [RLDatix].[dbo].[fSales] AS S
	LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
	GROUP BY YEAR(S.OrderDate)
), TotNetProfit_CTE AS (
	SELECT [Net Profit] , [YEAR]
	FROM #06NETProfit_tmp
)
Select totC.[Net Profit]  / GS.[Tot Gross Sales] , GS.[Year]
	FROM TotGrossSales_CTE AS GS
JOIN TotNetProfit_CTE as totC ON GS.[Year] = totC.[YEAR]



/* 08 ONLINE Sales */

Select SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales], YEAR(S.OrderDate)
FROM [RLDatix].[dbo].fsales S
JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
WHERE StoreKey = 0
GROUP BY YEAR(s.OrderDate)


/* 09 Phisical Sales (Shops) */

Select SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales], YEAR(S.OrderDate)
FROM [RLDatix].[dbo].fsales S
JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
WHERE StoreKey <> 0
GROUP BY YEAR(s.OrderDate)



/* 10 Tot Sales of Current/Last Year */

Declare @LastYear as int;
Select @LastYear = YEAR(MAX(ORDERDATE)) FROM [RLDatix].[dbo].[fSales]

Select SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales], YEAR(S.OrderDate) AS [Year]
FROM [RLDatix].[dbo].[fSales] AS S
LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
WHERE YEAR(S.OrderDate) = @LastYear
GROUP BY  YEAR(S.OrderDate)


/* 11 Tot Sales of Previous/Last Year */

Declare @LastYear as int;
Select @LastYear = YEAR(DATEADD(YEAR,-1,MAX(ORDERDATE))) FROM [RLDatix].[dbo].[fSales]

Select SUM(S.[Quantity] * P.[UnitPriceUSD]) AS [Tot Gross Sales], YEAR(S.OrderDate) AS [Year]
FROM [RLDatix].[dbo].[fSales] AS S
LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
WHERE YEAR(S.OrderDate) = @LastYear
GROUP BY  YEAR(S.OrderDate)


/* 12 Avg Shipping Days by Year*/

Select AVG(DATEDIFF(day,S.OrderDate,S.DeliveryDate)) AS [AVGShipDays],YEAR(S.OrderDate) AS [Year]
FROM [RLDatix].[dbo].[fSales] AS S
WHERE DeliveryDate <> '1900-01-01'
GROUP BY YEAR(S.OrderDate)


/* 13 Tot of Active Customers */


DECLARE @SelectedYear INT = 2020;

-- Measure 1: Active Customers
-- This query identifies customers who have made at least one sale in the @SelectedYear.
SELECT dc.CustomerKey,
    dc.Name, 
    'Active' AS CustomerStatus
	, @SelectedYear AS [YEAR]
FROM dCustomers AS dc
WHERE EXISTS ( SELECT 1
        FROM fSales AS fs
        WHERE fs.CustomerKey = dc.CustomerKey
            AND YEAR(fs.OrderDate) = @SelectedYear );

-- 2nd Option  

SELECT distinct S.CustomerKey , C.Name,Country ,'Active' AS CustomerStatus,YEAR(s.OrderDate)
FROM [RLDatix].[dbo].[fSales] AS S
LEFT JOIN dCustomers AS C ON S.CustomerKey = C.CustomerKey
WHERE YEAR(s.OrderDate) = 2020

DECLARE @SelectedYear INT = 2020;

-- Measure 2: Inactive Customers
-- This query identifies customers who exist in dCustomer but have NOT made any sales in the @SelectedYear.
SELECT dc.CustomerKey,
    dc.[Name], 
    'Inactive' AS CustomerStatus
	,@SelectedYear AS [Year]
FROM dCustomers AS dc
WHERE NOT EXISTS ( SELECT 1
					FROM fSales AS fs
					WHERE fs.CustomerKey = dc.CustomerKey
						AND YEAR(fs.OrderDate) = @SelectedYear);

/* 2nd Option fo Inactive customers */

DECLARE @SelectedYear INT = 2020;

SELECT C.CustomerKey , C.Name,Country,'Inactive' AS CustomerStatus, @SelectedYear as [Year]
FROM [RLDatix].[dbo].[fSales] AS S
RIGHT OUTER JOIN dCustomers AS C ON S.CustomerKey = C.CustomerKey
WHERE @SelectedYear = 2020 AND S.CustomerKey is NULL 


;DECLARE @SelectedYear INT = 2020;
-- Optional: Combined view of Active and Inactive Customers with counts
-- This query provides a summary count for both active and inactive customers.
;WITH CustomerActivity AS (
		SELECT dc.CustomerKey,
        CASE WHEN EXISTS (
                SELECT 1 FROM fSales AS fs
                WHERE fs.CustomerKey = dc.CustomerKey 
                    AND YEAR(fs.OrderDate) = @SelectedYear
            ) THEN 'Active'
            ELSE 'Inactive'
        END AS CustomerStatus
    FROM dCustomers AS dc
)
SELECT
    ca.CustomerStatus,
    COUNT(ca.CustomerKey) AS NumberOfCustomers
FROM CustomerActivity AS ca
GROUP BY ca.CustomerStatus;



/* 17 Top Products Sold by Volume */ 

;WITH CTE AS (
	SELECT P.ProductName , S.[Quantity] * P.[UnitPriceUSD] AS Sold
	,ROW_NUMBER() OVER (ORDER BY S.[Quantity] * P.[UnitPriceUSD] DESC) AS [Rank]
	FROM [RLDatix].[dbo].[fSales] AS S
	LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
)
SELECT * from CTE WHERE Rank <11

/* 19  Least Sold Products  */

	SELECT top 10 P.ProductName, 
		SUM(S.[Quantity] * P.[UnitPriceUSD]) AS Sold
		FROM [RLDatix].[dbo].[fSales] AS S
	LEFT JOIN [dbo].[dProducts] AS P ON  S.ProductKey = P.ProductKey 
	group by P.ProductName 
	ORDER BY 2 DESC





