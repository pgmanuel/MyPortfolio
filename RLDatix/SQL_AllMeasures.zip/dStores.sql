/****** Script for SelectTopNRows command from SSMS  ******/

SELECT 'StoreKey' = CAST([StoreKey] AS INT)
      ,'Country' = CAST([Country] AS VARCHAR(50))
      ,'State' = CAST([Square Meters]AS VARCHAR(100))
      ,'SquareMeters' = CAST(CAST([Square Meters] AS INT) AS DECIMAL(10,2))
      ,'OpenDate' = CAST(TRY_CONVERT(datetime, [Open Date], 111) AS DATE)
--INTO [RLDatix].[dbo].[dStores]
FROM [RLDatix].[dbo].[stgStores]