/****** Script for SelectTopNRows command from SSMS  ******/
SELECT 'ProductKey' = CAST([ProductKey] AS INT)
      ,'ProductName' = CAST([Product Name] AS VARCHAR(200))
      ,[Brand] = CAST([Brand] AS VARCHAR(50))
      ,[Color] = CAST(Color AS VARCHAR(50))
      ,'UnitCostUSD' = CAST(REPLACE(REPLACE([Unit Cost USD],'$',''),',','') AS DECIMAL(10,2))
      ,'UnitPriceUSD' = CAST(REPLACE(REPLACE([Unit Price USD],'$',''),',','') AS DECIMAL(10,2))
	  ,'SubcategoryKey' = CAST([SubcategoryKey] AS INT)
      ,'Subcategory' = CAST([SubcategoryKey] AS VARCHAR(100))
      ,[CategoryKey] = CAST([CategoryKey] AS INT)
      ,[Category] = CAST([Category] AS VARCHAR(100))
  INTO [RLDatix].[dbo].dProducts
  FROM [RLDatix].[dbo].[stgProducts]